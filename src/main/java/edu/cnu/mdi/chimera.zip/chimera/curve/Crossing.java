package edu.cnu.mdi.chimera.curve;

import edu.cnu.mdi.chimera.util.SphericalVector;

/**
 * Represents a crossing of a curve with a grid line, storing the parameter value
 * at which the crossing occurs and the index of the grid line.
 *
 * @param curve the the curve that crosses the grid line
 * @param t     the parameter value along the curve where the crossing occurs
 * @param value the value of the curve's coordinate at the crossing (e.g., theta or phi in radians)
 * @param index the index of the grid line that is crossed
 */
public record Crossing(BaseCurve curve, double t, double value, int index) {
	
	private static final double TOL = 1.0e-9;

	/**
	 * Returns a string representation of the crossing, including the parameter value,
	 * the coordinate value in degrees, and the grid line index.
	 *
	 * @return a formatted string summarizing the crossing
	 */
	public String summaryString() {
		return String.format("%s, t: %.3f, value: %.3f, index: %d", 
				curve.shortString(), t, Math.toDegrees(value), index);
	}
	
	/**
	 * Computes the great-circle distance between this crossing and another crossing.
	 * The distance is calculated based on the spherical coordinates (theta and phi)
	 * of the two crossings, using the great-circle distance formula.
	 *
	 * @param other the other crossing to compare against
	 * @return the great-circle distance in radians between the two crossings
	 */
	public double distanceTo(Crossing other) {
		BaseCurve c1 = this.curve;
		BaseCurve c2 = other.curve;
		double theta1 = c1.getThetaFunction().value(this.t);
		double phi1 = c1.getPhiFunction().value(this.t);
		double theta2 = c2.getThetaFunction().value(other.t);
		double phi2 = c2.getPhiFunction().value(other.t);
		return SphericalVector.gcDistance(theta1, phi1, theta2, phi2);
	}
	
	/**
	 * Determines whether this crossing is effectively the same as another crossing,
	 * based on whether the great-circle distance between them is less than a specified tolerance.
	 *
	 * @param other the other crossing to compare against
	 * @return true if the crossings are considered the same, false otherwise
	 */
	public boolean sameCrossing(Crossing other) {
		return distanceTo(other) < TOL;
	}
}
