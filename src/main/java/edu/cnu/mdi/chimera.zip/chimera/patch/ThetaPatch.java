package edu.cnu.mdi.chimera.patch;

import java.util.ArrayList;
import java.util.List;

import edu.cnu.mdi.chimera.app.ChimeraApp;
import edu.cnu.mdi.chimera.curve.BaseCurve;
import edu.cnu.mdi.chimera.curve.Crossing;
import edu.cnu.mdi.chimera.curve.GeneralCurve;
import edu.cnu.mdi.chimera.curve.ThetaCurve;
import edu.cnu.mdi.chimera.grid.CartesianGrid;
import edu.cnu.mdi.chimera.grid.Grid1D;
import edu.cnu.mdi.chimera.grid.SphericalGrid;
import edu.cnu.mdi.chimera.util.MathUtil;
import edu.cnu.mdi.chimera.util.Point3D;

/**
 * A theta-patch is a {@link PrePatch} sliced by one band {@code [θ_lo, θ_hi]}
 * of the spherical theta grid (paper §6.4). It carries a 4-tuple
 * {@code (nx, ny, nz, nTheta)} with {@code nPhi = -1} until the phi splice.
 */
public class ThetaPatch extends BasePatch {

    private ThetaPatch(List<BaseCurve> curves,
                       int nx, int ny, int nz, int nTheta) {
        super(curves, nx, ny, nz, nTheta, -1);
    }

    @Override
    public boolean containsPoint(double x, double y, double z) {
    	CartesianGrid cartesianGrid = ChimeraApp.getInstance().getCartesianGrid();
    	SphericalGrid sphericalGrid = ChimeraApp.getInstance().getSphericalGrid();
    	
        int[] cart = cartesianGrid.getIndices(x, y, z, new int[3]);
        if (cart[0] != nx || cart[1] != ny || cart[2] != nz) return false;
        double theta = Math.acos(Math.max(-1.0, Math.min(1.0, z / radius)));
        int[] sph = sphericalGrid.getIndices(theta, Math.atan2(y, x), new int[2]);
        return sph[0] == nTheta;
    }

    private static final double THETA_TOL    = 1.0e-9;
    private static final double ENDPOINT_TOL = 1.0e-8;

    // -----------------------------------------------------------------------
    // Theta splice
    // -----------------------------------------------------------------------

    /**
     * Slices a {@link PrePatch} along all theta grid lines it spans, returning
     * one {@link ThetaPatch} per theta band.
     *
     * <h3>Key insight</h3>
     * <p>The boundary curves of each band must form a closed loop in traversal
     * order. ThetaCurve connectors between bands must therefore be inserted
     * at the exact position in the sequence where the crossing occurs —
     * not appended at the end. We achieve this with a single ordered walk:</p>
     * <ul>
     *   <li>We maintain one open curve-list per band, representing the
     *       partially-built boundary traversed so far.</li>
     *   <li>When we cross from band A to band B at point P, we record P as
     *       band A's pending exit point.</li>
     *   <li>When we later cross back into band A at point Q (on the same or
     *       a different cut line), we immediately prepend a
     *       {@code ThetaCurve(P→Q)} — wait, we APPEND it since we are
     *       building in traversal order and P was already emitted.</li>
     *   <li>After the full loop, each band's pending exit is connected back
     *       to its very first point by the final ThetaCurve.</li>
     * </ul>
     */
    public static List<ThetaPatch> splice(PrePatch pre) {
    	
        SphericalGrid sphGrid   = ChimeraApp.getInstance().getSphericalGrid();
         ArrayList<ThetaPatch> result = new ArrayList<>();
        
        //do some sanity checks
        List<Crossing> allCrossings = pre.getAllThetaCrossings();
        allCrossings = removeDuplicateCrossings(allCrossings);
		int numThetaCrossings = allCrossings.size();
		
		if (numThetaCrossings == 0) {
			// sanity check
			int thetaIndex = -1;
			for (BaseCurve curve : pre.curves) {
				if (thetaIndex < 0) {
					thetaIndex = curve.getMidpointThetaIndex();
				}
				else if (curve.getMidpointThetaIndex() != thetaIndex) {
					System.err.println(
							"[ThetaPatch] Warning: PrePatch has no theta crossings but curves have differing midpoint theta indices.");
					break;
				}
			}
			ThetaPatch patch = new ThetaPatch(pre.curves, pre.nx, pre.ny, pre.nz, thetaIndex);
			result.add(patch);
		} // num theta crossings== 0
		else if (numThetaCrossings == 1) {
//			Warning: PrePatch has only one theta crossing.
//			This can occur when curves end exactly on a theta line. 
//			Should be able to treat as a prepatch with no crossings
//			if it is close to a gridline.
			Crossing crossing = allCrossings.get(0);
			double t = crossing.t();
			if (Math.abs(t) < ENDPOINT_TOL || Math.abs(t - 1.0) < ENDPOINT_TOL) {
				ThetaPatch patch = new ThetaPatch(pre.curves, pre.nx, pre.ny, pre.nz, crossing.index());
				result.add(patch);
			} else {
				System.err.println("  Crossing is NOT near an endpoint (t=" + t
						+ "). This may indicate a problem with the prepatch construction or the crossing detection. The splice may fail or produce incorrect results.");
				System.exit(1);
			}
			
		} else if (pre.polar()) {
			System.err.println("[ThetaPatch] polar splice with " + numThetaCrossings + " theta crossings.");
			polarSplice(pre);
		} else {
			// should be even number of crossings
			if (numThetaCrossings % 2 != 0) {
				System.err.println("[ThetaPatch] Warning: PrePatch has odd number of theta crossings ("
						+ numThetaCrossings + ").");

				for (Crossing c : allCrossings) {
					System.err.println(c.summaryString());
				}
				
				System.err.println("  This may indicate a problem with the prepatch construction or the crossing detection. The splice may fail or produce incorrect results.");
				System.exit(1);
			}
		} //num theta crossings > 0

        return result;
    }
    
    private static void polarSplice(PrePatch pre) {
    	
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /**
     * Returns the 0-based band index (relative to nThetaLo) for the given
     * theta value.  Band k spans {@code [cutTheta[k-1], cutTheta[k]]}.
     */
    private static int bandOf(double theta, double[] cutTheta, int numBands) {
        int band = 0;
        for (double cut : cutTheta) {
            if (theta > cut + ENDPOINT_TOL) band++;
            else break;
        }
        return Math.max(0, Math.min(numBands - 1, band));
    }

    /**
     * Finds all t values where {@code curve.theta(t)} equals one of the
     * {@code cutTheta} values, sorted by ascending t, skipping near-endpoint
     * hits that are within {@link #ENDPOINT_TOL} of 0 or 1.
     */
    /**
     * Finds all t values in (0, 1) where {@code curve.theta(t)} equals one of
     * the {@code cutTheta} values, sorted by ascending t.
     *
     * <p>Endpoint hits (t ≈ 0 or t ≈ 1) are skipped intentionally. A crossing
     * at t=0 means the curve starts exactly on a gridline — the band change is
     * handled by the caller's {@code bandOf} logic at curve boundaries. A
     * near-endpoint hit at t≈1 must NOT be treated as a mid-curve crossing
     * because {@code curve.getPoint(t≈1)} would return the curve endpoint
     * (whose theta may differ slightly from the gridline) causing a ThetaCurve
     * to be constructed with mismatched theta values and a loop gap.</p>
     */
    /**
     * Finds ALL t values in (0,1) where {@code curve.theta(t)} equals one of
     * the cut thetas, sorted by ascending t. Searches repeatedly in the
     * remaining interval after each found root to catch multiple crossings
     * of the same gridline (e.g. a curve that bows above a cut and returns).
     */
    private static List<double[]> findCrossings(BaseCurve curve, double[] cutTheta) {
        List<double[]> crossings = new ArrayList<>();

        // True theta range including interior samples.
        double curveMin = curve.sv0.theta, curveMax = curve.sv0.theta;
        for (int s = 1; s <= 20; s++) {
            double th = (s == 20) ? curve.sv1.theta : curve.theta(s / 20.0);
            curveMin = Math.min(curveMin, th);
            curveMax = Math.max(curveMax, th);
        }

        for (int k = 0; k < cutTheta.length; k++) {
            double cut = cutTheta[k];
            if (cut < curveMin - ENDPOINT_TOL || cut > curveMax + ENDPOINT_TOL) continue;

            // Skip endpoints on the cut.
            if (Math.abs(curve.sv0.theta - cut) < ENDPOINT_TOL) continue;
            if (Math.abs(curve.sv1.theta - cut) < ENDPOINT_TOL) continue;

            // Search for ALL crossings of this cut by repeatedly scanning
            // the remaining interval after each found root.
            double tLo = ENDPOINT_TOL;
            double tHi = 1.0 - ENDPOINT_TOL;
            while (tLo < tHi - ENDPOINT_TOL) {
                double t = MathUtil.computeT(
                        curve.getThetaFunction(), cut, tLo, tHi, THETA_TOL, 200);
                if (Double.isNaN(t)) break;
                crossings.add(new double[]{t, k});
                // Advance past this root to find the next one.
                tLo = t + ENDPOINT_TOL * 100;
            }
        }

        crossings.sort((a, b) -> Double.compare(a[0], b[0]));
        return crossings;
    }

    /** Returns a subrange of {@code curve} over {@code [t0, t1]}. */
    private static BaseCurve subrange(BaseCurve curve, double t0, double t1) {
        if (t0 >= t1) return null;
        if (curve instanceof GeneralCurve gc) return gc.subrange(t0, t1);
        return new ThetaCurve(curve.getPoint(t0), curve.getPoint(t1), curve.radius);
    }
}